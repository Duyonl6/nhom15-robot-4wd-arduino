# Thư viện kèm theo

| Thư viện | Phiên bản | Thay đổi và nguồn |
|---|---|---|
| DabbleRobot | nền Dabble 1.5.2 | Bản vá cục bộ dùng NeoSWSerial tại A3/A2; giữ LICENSE của STEMpedia; xem ROBOT_PATCH.md |
| NeoSWSerial | 3.0.5 | Nguồn SlashDevin/NeoSWSerial, commit 5c29046ac1c19e72128a17afc279fd501bc0063c; bản vá chia sẻ PCINT và thời gian RX; GPLv3+ theo header nguồn |
| Servo | 1.3.0 | Thư viện Arduino, giữ LICENSE.txt và mã gốc |

Arduino core AVR 1.8.8 là gói toolchain nền, cài bằng Arduino CLI/IDE. Không đổi thư viện toàn cục của máy khi dùng lệnh `--library` chỉ định trong README.
