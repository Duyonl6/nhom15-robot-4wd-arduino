# Bản vá robot cục bộ

Nền: NeoSWSerial 3.0.5 từ https://github.com/SlashDevin/NeoSWSerial, commit 5c29046ac1c19e72128a17afc279fd501bc0063c.

- Cho phép PORTC PCINT1 dùng chung A3 Bluetooth RX và A1 Echo.
- Gọi hook nhận trong vòng TX khi ngắt đang khóa.
- Mở rộng timestamp RX theo bước 4 µs lên 16 bit và sửa phép cộng cửa sổ để tránh tràn 8 bit.
- ISR PCINT được khai báo bên sketch robot.

Bản sao đã có trong gói firmware v2.4 ngày 22/11/2026; giữ nguyên nội dung nguồn khi đóng gói. Các header nguồn công bố GNU GPLv3 hoặc mới hơn.
