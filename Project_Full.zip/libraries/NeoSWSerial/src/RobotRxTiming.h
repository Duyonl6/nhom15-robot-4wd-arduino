#pragma once
#include <stdint.h>
// BT05 can leave long HIGH gaps around 0xFF. Do not truncate dt+window to
// 8 bits (e.g. 250+10), and retain elapsed time across Timer0's 1.024ms wrap.
static inline uint16_t robotRxBitTimes(uint16_t dt,uint8_t window,uint8_t scale){
 return (uint16_t)(((uint32_t)dt+window)*scale>>10);
}
