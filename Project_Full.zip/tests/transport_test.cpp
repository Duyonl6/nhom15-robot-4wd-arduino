#include <cassert>
#include <iostream>
#include <string>
#include "../robot_4wd_3in1/BtLinkMonitor.h"
void text(BtLinkMonitor& m,const std::string& s,uint32_t t){for(uint8_t c:s)m.feed(c,t++);}
int main(){
 BtLinkMonitor m;assert(!m.healthy(0));
 text(m,"TX=\r\n",100);assert(m.healthy(904)&&!m.healthy(905));
 const uint8_t p[]={255,1,1,1,2,0,1,0};
 for(int i=0;i<8;++i){m.feed(p[i],1000+i);assert(m.pending()==(i==7));}
 assert(m.digitalFrames==1);for(uint8_t c:p)assert(m.read()==c);assert(!m.pending());
 text(m,"TX=\r\n",1100);assert(m.healthy(1104));
 text(m,"ERROR\r\n",1200);assert(!m.healthy(1207)&&m.takeBadEvent());
 assert(!m.takeBadEvent());
 m.feed(255,1300);m.feed(1,1301);m.tick(1342);assert(m.takeBadEvent());
 // A lost start byte leaves unexpected payload, which trips rather than retaining a held key.
 m.feed(1,1400);assert(m.takeBadEvent());
 text(m,"TX=\r\n",1500);assert(m.healthy(1504));
 uint8_t broken[]={255,1,1,1,2,0,1,42};
 for(int i=0;i<8;++i)m.feed(broken[i],1600+i);assert(!m.pending()&&m.takeBadEvent());
 const uint8_t board[]={255,0,3,0,0};
 for(int i=0;i<5;++i)m.feed(board[i],1700+i);
 assert(m.pending());for(uint8_t c:board)assert(m.read()==c);
 m.feed(0,1800);assert(!m.takeBadEvent()); // Spare app end byte is benign.
 BtLinkMonitor wrap;text(wrap,"TX=\r\n",0xFFFFFF00u);
 assert(wrap.healthy(0x100)&&!wrap.healthy(0x300));
 std::cout<<"PASS: exact ACK/error, timeout boundary, fragmented packets, frame timeout, corruption, startup frame, clock wrap\n";
}
