#define ROBOT_HOST_TEST
#include <cassert>
#include <iostream>
#include "Arduino.h"
#include "Dabble.h"
unsigned long fakeMs=0;int inputPins[32],pwmPins[32];MockDabble Dabble;
#include "../robot_4wd_3in1/robot_4wd_3in1.ino"
void ack(){for(char c:"TX=\r\n")if(c)btLink.feed((uint8_t)c,fakeMs);}
void packet(uint8_t f,uint8_t a=0){
 Dabble.data[0]=f;Dabble.data[1]=a;
 static_cast<ModuleParent&>(packetObserver).processFrame();
}
void advance(unsigned long to,bool connected=true){
 while(fakeMs<to){
  ++fakeMs;
  if(connected&&fakeMs%250==0)ack();
  if(fakeMs%50==0){++ticksL;++ticksR;}
  loop();
 }
}
void press(uint8_t f){packet(f);packet(0);}
int main(){
 for(int&i:inputPins)i=HIGH;setup();
 advance(49090);packet(4);advance(49479);packet(0);
 advance(54836);packet(1);advance(55106);packet(0);
 advance(61391);packet(0,1);loop();assert(running&&outputL==140&&outputR==140);
 // No new button frames for 12 seconds; only module link replies and encoder progress.
 advance(73391);assert(running&&outputL==140&&outputR==140);
 packet(0);loop();assert(running&&outputL==0&&outputR==0);
 advance(120000);packet(0,1);loop();assert(running&&outputL==140);
 // Simulate silent UART/link loss while the held direction remains latched.
 advance(120901,false);assert(!running&&needRelease&&outputL==0&&outputR==0);
 ack();loop();assert(!running); // Fresh link does not restart stale motion.
 packet(0,1);loop();assert(!running); // Held direction cannot bypass neutral lock.
 packet(0);press(1);packet(0,1);loop();assert(running&&outputL==140);
 btLink.feed('x',fakeMs);loop();assert(!running&&needRelease&&outputL==0);
 ack();packet(0);press(1);packet(0,1);loop();assert(running);
 Dabble.fid=2;packet(0);assert(!running&&needRelease&&outputL==0);
 Dabble.fid=1;ack();packet(0);press(1);press(1<<4);assert(!running&&outputL==0);
 press(1<<3);press(1);advance(fakeMs+12000);assert(running&&mode==OBSTACLE);
 std::cout<<"PASS: real idle timing, 12s held direction, immediate release, 800ms link loss, neutral/restart, corrupt UART, app mode change, Cross stop, autonomous >2.5s\n";
}
