#include <cassert>
#include <iostream>
#include "../robot_4wd_3in1/SonarCapture.h"
int main(){
 SonarCapture s;uint32_t us=99;
 assert(!s.take(10,us));s.start(100);s.edge(false,110);assert(s.phase==1);
 s.edge(true,200);s.edge(false,1833);assert(s.take(1900,us)&&us==1633);
 assert(!s.take(2000,us));
 s.start(3000);assert(!s.take(27999,us));assert(s.take(28000,us)&&us==0&&s.phase==0);
 // Echo rose but no target: open range (clear), not a sensor failure.
 s.start(30000);s.edge(true,30500);assert(!s.take(54999,us));
 assert(s.take(55000,us)&&us==SonarCapture::OPEN_RANGE&&s.phase==0);
 assert(us*0.01715f>400.0f);
 s.start(0xFFFFFF00u);s.edge(true,0xFFFFFF80u);s.edge(false,0x80u);
 assert(s.take(0x100u,us)&&us==256);
 s.start(500);s.edge(true,600);s.edge(false,1000);s.start(1100);
 assert(!s.take(1200,us)); // A new acquisition must not reuse an old sample.
 std::cout<<"PASS: rising/falling edges, stray edge, exact timeout, open range, consumed sample, restart, clock wrap\n";
}
