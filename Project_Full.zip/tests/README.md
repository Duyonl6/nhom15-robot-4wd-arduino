# Kiểm thử host

Chạy từ thư mục gốc bằng `python3 scripts/test_host.py`. Cần C++ compiler có ASan/UBSan (clang++ hoặc g++). Sáu bộ kiểm tra controller, giữ nút, parser UART, siêu âm, PWM dò line và thời gian RX. Header Arduino/Dabble/Servo trong thư mục này là mock cho máy tính, không phải thư viện nạp lên Nano.

Kết quả ghi vào `data/submission-host-tests.json`. Test host không xác nhận chuyển động ngoài thực tế.
