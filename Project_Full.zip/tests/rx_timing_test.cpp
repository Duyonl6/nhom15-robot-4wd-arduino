#include <cassert>
#include <iostream>
#include "../libraries/NeoSWSerial/src/RobotRxTiming.h"
int main(){
 assert(robotRxBitTimes(26,10,39)==1);
 assert(robotRxBitTimes(234,10,39)==9);
 assert(robotRxBitTimes(250,10,39)==9);
 assert(robotRxBitTimes(256,10,39)==10);
 assert(robotRxBitTimes(500,10,39)==19);
 uint16_t a=65500,b=214;
 assert(robotRxBitTimes((uint16_t)(b-a),10,39)==9);
 std::cout<<"PASS RX timing: 0xFF idle gap, uint8 addition overflow, extended counter wrap\n";
}
