#define ROBOT_HOST_TEST
#include <cassert>
#include <iostream>
#include "Arduino.h"
#include "Dabble.h"
unsigned long fakeMs=1000;int inputPins[32],pwmPins[32];MockDabble Dabble;
#include "../robot_4wd_3in1/robot_4wd_3in1.ino"
void packet(uint8_t f,uint8_t a=0){
 for(char c: "TX=\r\n")if(c)btLink.feed((uint8_t)c,fakeMs);
 Dabble.data[0]=f;Dabble.data[1]=a;
 static_cast<ModuleParent&>(packetObserver).processFrame();
}
void press(uint8_t f){packet(f);packet(0);}
int main(){
 for(int&i:inputPins)i=HIGH;
 setup(); assert(!running && outputL==0 && outputR==0 && !headAttached);
 packet(1);assert(!running); // no neutral frame since boot
 packet(0);press(1);assert(running && mode==MANUAL && !headAttached);
 packet(0,1);loop();assert(outputL==140 && outputR==140);
 packet(0);loop();assert(outputL==0 && outputR==0);
 press(1<<5);assert(!running && mode==LINE);
 press(1);assert(running && headAttached);distanceCM=-1;followLine();assert(outputL==0);
 fakeMs+=500;distanceCM=50;inputPins[10]=LOW;followLine();
 fakeMs+=20;followLine();assert(running && outputL>0 && outputR>0);
 inputPins[10]=HIGH;followLine();fakeMs+=1501;followLine();assert(!running && !headAttached);
 press(1<<3);assert(mode==OBSTACLE && !running);
 press(1);distanceCM=12;fakeMs+=500;avoidObstacles();assert(avoidState==SCAN_LEFT && !outputL);
 fakeMs+=701;freshDistance=true;distanceCM=35;avoidObstacles();assert(avoidState==SCAN_RIGHT);
 fakeMs+=701;distanceCM=40;avoidObstacles();assert(avoidState==CENTER_HEAD);
 fakeMs+=501;avoidObstacles();assert(segmentActive && segPwmL>0 && segPwmR<0);
 fakeMs+=901;assert(segmentUpdate()==-1 && fault && !running);
 press(1);assert(running && !fault);
 motor(100,100);press(1<<4);assert(!running && outputL==0 && outputR==0);
 press(1<<2);press(1);assert(running);packet(0,1);loop();assert(outputL>0);
 fakeMs+=2501;loop();assert(!running && needRelease && outputL==0);
 packet(1);assert(!running);packet(0);press(1);assert(running);
 startSegment(100,100,10);ticksL+=10;assert(segmentUpdate()==0 && outputL==0 && outputR==100);
 ticksR+=10;assert(segmentUpdate()==1 && outputR==0);
 startSegment(100,100,10000);fakeMs+=6001;ticksL++;ticksR++;
 assert(segmentUpdate()==-1 && !running);
 Dabble.len=1;auto t=lastPacket;fakeMs+=10;packet(1);assert(lastPacket==t && !running);
 Dabble.len=2;needRelease=false;havePacket=true;
 packet(0);selectMode(MANUAL);press(1);motor(120,120);
 fakeMs+=901;motionGuard();assert(fault && !running && outputL==0);
 press(1);motor(120,120);
 for(int i=0;i<15;i++){fakeMs+=100;++ticksL;++ticksR;motionGuard();assert(running && !fault);}
 fakeMs+=901;++ticksL;motionGuard();assert(fault && !running); // one missing encoder
 selectMode(LINE);press(1);routeStep=1;startSegment(100,100,100);
 freshDistance=true;distanceCM=5;followLine();assert(fault && !running && outputL==0);
 press(1);routeStep=1;startSegment(100,100,100);freshDistance=true;distanceCM=-1;
 followLine();assert(fault && !running);
 std::cout<<"PASS: startup, neutral interlock, all modes, control release, sonar failure, line loss, scan/turn, encoder stall, stop, link expiry/reconnect, wheel completion, segment deadline, malformed packet; continuous-drive stall, encoder progress, single-wheel stall, close/no-echo forward-route stops\n";
}
