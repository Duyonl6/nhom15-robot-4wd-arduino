#pragma once
#include <cstdint>
#include <cmath>
#include <cstdlib>
using byte=uint8_t;
#define A0 14
#define A1 15
#define A2 16
#define A3 17
#define A5 19
#define HIGH 1
#define LOW 0
#define INPUT 0
#define OUTPUT 1
#define INPUT_PULLUP 2
#define RISING 3
#define LED_BUILTIN 13
#define PI 3.14159265358979323846
#define constrain(x,a,b) ((x)<(a)?(a):((x)>(b)?(b):(x)))
extern unsigned long fakeMs;
extern int inputPins[32],pwmPins[32];
inline unsigned long millis(){return fakeMs;}
inline unsigned long micros(){return fakeMs*1000;}
inline void noInterrupts(){} inline void interrupts(){}
inline void digitalWrite(int,int){} inline void pinMode(int,int){}
inline int digitalRead(int p){return inputPins[p];}
inline void analogWrite(int p,int x){pwmPins[p]=x;}
inline void delayMicroseconds(int){}
inline unsigned long pulseIn(int,int,unsigned long){return 0;}
inline int digitalPinToInterrupt(int p){return p;}
inline void attachInterrupt(int,void(*)(),int){}

inline unsigned long pulseInLong(int p,int v,unsigned long t){return pulseIn(p,v,t);}
