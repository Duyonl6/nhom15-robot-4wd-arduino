#pragma once
#include "Arduino.h"
struct MockDabble {
 byte mid=1,fid=1,nargs=1,len=2,data[2]={0,0};
 byte getModuleId(){return mid;} byte getFunctionId(){return fid;}
 byte getArgumentNo(){return nargs;} byte getArgumentLength(int){return len;}
 byte* getArgumentData(int){return data;}
 void begin(long,int,int){} void processInput(){}
};
extern MockDabble Dabble;
struct ModuleParent{ModuleParent(byte){} virtual void processFrame(){};virtual ~ModuleParent()=default;};
