#define ROBOT_HOST_TEST
#include <cassert>
#include <iostream>
#include "Arduino.h"
#include "Dabble.h"
unsigned long fakeMs=1000;int inputPins[32],pwmPins[32];MockDabble Dabble;
#ifndef ROBOT_SOURCE
#define ROBOT_SOURCE "../robot_4wd_3in1/robot_4wd_3in1.ino"
#endif
#include ROBOT_SOURCE
int main(){
#ifdef BASELINE_V22
 const int active=LOW;
#else
 const int active=LINE_ACTIVE_LEVEL;
#endif
 for(int&i:inputPins)i=!active;
 inputPins[10]=active;setup();mode=LINE;running=true;headMoved=0;
 distanceCM=100;freshDistance=false;
 int low=999,high=-1,zeros=0;
 // 0.4 m/s, 20 pulses/rev, 6.5cm wheel => 39.2 ticks/s, quantized to 0/1 tick
 // in a 20ms window. A centered line at steady speed must not repeatedly stop.
 for(int i=1;i<=100;++i){
  fakeMs=1000+20*i;ticksL=ticksR=(unsigned long)(i*.02f*.4f/.2042035f*20);
  followLine();low=std::min(low,outputL);high=std::max(high,outputL);zeros+=outputL==0;
 }
 std::cout<<"centered_line_PWM_min="<<low<<" max="<<high<<" zero_samples="<<zeros<<std::endl;
 assert(zeros==0&&low>=80&&high<=180);
}
