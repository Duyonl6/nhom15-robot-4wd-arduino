# Dữ liệu kiểm chứng

Robot dùng luật điều khiển và cảm biến; không có tập dữ liệu huấn luyện AI. `results.csv` là bảng tổng hợp minh chứng, không phải số đo hiệu năng tự tạo.

- `device-state.json`, `v24-final-compile.log`, `v24-final-independent-verify.log`: minh chứng nạp/biên dịch/đối chiếu lịch sử ngày 22/11/2026.
- `test-results.json`: 6 bộ kiểm thử host từ gói v2.4; `submission-host-tests.json` ghi kết quả chạy lại khi đóng gói bài nộp.
- `line-material-test.json`: kết quả chẩn đoán cảm biến HW-871. `mask=4` nghĩa là chỉ mắt giữa nhận vạch; `mask=0` là không mắt nào nhận vạch.
- `dependencies.json`: phiên bản và bản vá thư viện.
- `submission-compile.log`: biên dịch lại từ đúng thư viện đi kèm lúc đóng gói.
- `results.csv`: các cột `value` rỗng nếu chỉ có mô tả định tính. Không suy ra tỉ lệ thành công, sai số hay vận tốc thực tế từ kết quả này.

Nguồn gốc: gói robot-4wd-auto-2026-11-22 (firmware v2.4), bằng chứng ngày 22/11/2026. Đã bỏ đường dẫn tài khoản máy khỏi log để nộp bài. Xem phân biệt thử phần mềm/thử USB/phản hồi thử pin trong `../docs/verification.md`.
