# Mạch rõ

Hình thức lấy cảm hứng từ bản vẽ kỹ thuật: mọi đường nối có đích đến, mỗi khối biểu thị một chức năng. Bố cục theo lưới rõ ràng giúp người đọc hiểu hệ thống qua một lượt nhìn; khoảng trắng đóng vai trò như khoảng cách giữa các linh kiện. Từng điểm neo và lề phải được chỉnh với sự cẩn trọng của một bản vẽ hoàn thiện.

Màu xanh đậm tạo nền ổn định cho thông tin chính, xanh ngọc biểu thị đường truyền và kết quả, cam dùng cho cảm biến và phần còn cần hoàn thiện. Sắc độ được chọn kỹ để giữ tương phản khi in A4, thể hiện sự chăm chút trong từng cặp chữ và nền.

Nhịp thị giác đi từ tên đề tài sang mô hình, từ sơ đồ tới phương pháp và bằng chứng. Con số chỉ xuất hiện khi có vai trò giải thích, không dùng để trang trí. Sự chính xác của khoảng cách và kích thước tạo cảm giác về một sản phẩm đã được trau chuốt qua nhiều lần rà soát.

Chữ tiếng Việt rõ dấu, câu ngắn, nhãn nhất quán; minh họa kỹ thuật là phần giải thích cấu trúc, không giả làm ảnh sản phẩm thực. Mỗi mũi tên và nhãn đều phải được căn chỉnh thủ công cẩn thận, giữ một phong thái gọn, sắc nét và đáng tin.
