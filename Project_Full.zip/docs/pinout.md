# Sơ đồ chân theo mã v2.4

| Khối | Chân Arduino Nano | Ghi chú |
|---|---|---|
| L298N ENA / ENB | D5 / D6 | PWM; bỏ jumper ENA/ENB nếu dùng PWM |
| L298N IN1 / IN2 / IN3 / IN4 | D0 / D1 / D4 / D7 | D0/D1 dùng chung UART USB |
| Encoder trái / phải | D2 / D3 | Đếm cạnh lên, lọc 500 µs |
| Dò line trái sang phải | D8 / D9 / D10 / D11 / D12 | LOW = nhận vạch trên cụm đã đo |
| HC-SR04 Trig / Echo | A0 / A1 | Echo dùng ngắt PCINT |
| BT05 TX → Nano RX | A3 | 9600 baud |
| Nano TX → BT05 RX | A2 | Theo đúng mức điện áp đầu RX của module; không mặc định chịu 5 V |
| Servo đầu quét | A5 | Chỉ gắn khi chạy chế độ tự động |

Nguồn: pin map trực tiếp từ `robot_4wd_3in1.ino`; không phải xác nhận độc lập từng dây bằng ảnh. Nối chung GND giữa Nano, cảm biến, Bluetooth và cầu H; cấp nguồn động cơ qua khối công suất, không lấy dòng động cơ từ chân 5 V Nano.

**Tắt pin động cơ trước khi cắm USB/nạp code:** D0/D1 nối cầu H, lưu lượng serial có thể đổi trạng thái chân. Không bật Hardware Serial trong firmware production.
