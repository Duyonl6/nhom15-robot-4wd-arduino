# Kết quả và giới hạn kiểm chứng

## Đã có bằng chứng trước khi đóng gói (22/11/2026)

1. Firmware production v2.4 đã nạp và được đối chiếu độc lập: 16.422 byte flash; SRAM tĩnh 667 byte. Không ghi EEPROM/fuse. Đây là log lịch sử, không phải lần nạp mới trong tác vụ làm poster.
2. Sáu bộ hồi quy host đạt ASan/UBSan; thử thuật toán, khung Bluetooth, thời hạn, siêu âm và hồi quy PWM. Kết quả chạy lại khi đóng gói lưu riêng.
3. Người dùng xác nhận thử pin: lái tay và tránh vật cản ổn. Không có telemetry USB trong lần thử pin đó, chưa có thống kê nhiều lượt chạy.
4. Thử line: bo HW-871 phản hồi với vật đen mờ; băng dính đen bóng có thể bị đọc như nền trắng. Người dùng báo phải ấn đầu xe xuống thì cảm biến mới nhận vạch. Cần hạ cụm cảm biến đến khoảng cách đã đo thực tế; gợi ý ban đầu 3-6 mm, không để chạm sàn.

## Chưa xác minh

- Bám vạch toàn tuyến trên sàn sau khi hạ cảm biến; tốc độ, độ chính xác, tỉ lệ thành công nhiều lượt.
- Nhánh đường trống ngoài khoảng 4 m trên xe thật (đã thử host, đo trên xe chỉ tới khoảng 50 cm).
- Mất sóng, app treo hoặc thao tác tắt màn hình. Phản hồi `TX=` từ đúng module BT05 v6.1 chỉ chứng minh liên kết module; không chứng minh giao diện Dabble còn đáp ứng.
- Xung/vòng, đường kính bánh và góc quay cần hiệu chuẩn. Mốc 0,4 m/s trong mã là giá trị đặt theo mô hình, không phải vận tốc đo được.

Poster thể hiện chức năng đã xây dựng và kết quả ở đúng mức bằng chứng trên. Không dùng báo cáo v3 cũ làm nguồn xác nhận đã nạp vì v3 và v2.4 là hai nhánh khác nhau.
