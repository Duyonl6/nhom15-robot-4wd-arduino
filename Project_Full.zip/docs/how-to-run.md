# Cách chạy và trình diễn

## Chuẩn bị

- Arduino Nano ATmega328P, L298N, 4 động cơ, 2 encoder, HC-SR04 + servo, HW-871 5 mắt và BT05 v6.1.
- Điện thoại có Dabble, chọn GamePad → Digital; kết nối BT05 trong ứng dụng.
- Với dò line: dùng vạch đen mờ rộng khoảng 1,5-2 cm trên nền sáng. Hạ cảm biến để khi xe đứng tự nhiên mắt trên vạch vẫn nhận LOW (đèn tắt), mắt trên nền trắng HIGH (đèn sáng).

## Biên dịch

Dùng Arduino CLI với core Arduino AVR 1.8.8. Các thư viện cần thiết đã nằm trong `libraries/`.

```sh
arduino-cli core install arduino:avr@1.8.8
arduino-cli compile --fqbn arduino:avr:nano:cpu=atmega328 --library libraries/DabbleRobot --library libraries/NeoSWSerial --library libraries/Servo robot_4wd_3in1
```

Arduino IDE: đóng IDE, sao chép 3 thư viện trong `libraries/` vào thư mục sketchbook/libraries; tránh để đồng thời Dabble gốc và DabbleRobot gây chọn nhầm. Mở `robot_4wd_3in1/robot_4wd_3in1.ino`, chọn Arduino Nano / ATmega328P. Thư viện đã vá cần giữ nguyên.

## Nạp

Tắt pin động cơ rồi cắm USB. Chọn đúng cổng bo. Bản đã kiểm chứng dùng bootloader Nano ATmega328P 115200, không chọn Old Bootloader nếu chưa có lý do.

```sh
arduino-cli board list
# Thay PORT bằng đúng cổng của bo, ví dụ COM3 trên Windows.
arduino-cli upload --fqbn arduino:avr:nano:cpu=atmega328 --port PORT robot_4wd_3in1
```

Rút USB trước khi bật pin để trình diễn. Lúc đầu kê bánh lên để kiểm hướng và nút dừng.

## Điều khiển

| Nút Dabble Digital | Tác dụng |
|---|---|
| × hoặc SELECT | Dừng; bấm-thả × một lần sau khi kết nối để xác lập trung tính |
| △ rồi START | Lái tay; giữ mũi tên để chạy, thả để dừng |
| □ rồi START | Dò line; xe chờ nhận vạch, mất vạch hơn 1,5 s thì dừng |
| ○ rồi START | Tránh vật cản; gặp vật dưới 20 cm thì quét trái/phải và đổi hướng |
| START khi đang chạy | Tạm dừng |

Mỗi lần đổi chế độ, bấm START lại. Sau lỗi/kết nối lại, thả hết nút rồi khởi động lại bằng START.

## Thông số dùng trong mã

- Bluetooth 9600 baud; kiểm liên kết BT05 khoảng 250 ms, hết hạn 800 ms.
- PWM tay 140, tránh vật 115, nền dò line 110 (thang 0-255; mã giới hạn tùy nhánh).
- Dò line: PD lái theo trọng số 5 mắt, PI bù tốc độ cập nhật 200 ms. Encoder danh định 20 xung/vòng, bánh danh định 6,5 cm: cần hiệu chuẩn.
- Tránh vật: ngưỡng 20 cm. Bảo vệ tiến trong đường vòng dò line có ngưỡng riêng trong mã.

Các thông số cài đặt không phải số đo hiệu năng trên sàn. Xem `verification.md` trước khi diễn giải kết quả.
