from pathlib import Path
import subprocess, tempfile, json, shutil
root=Path(__file__).resolve().parents[1]
compiler=shutil.which('clang++') or shutil.which('g++')
if not compiler: raise SystemExit('Need clang++ or g++')
names=['test','continuous_regression','transport_test','sonar_test','line_pwm_regression','rx_timing_test']
results=[]
with tempfile.TemporaryDirectory(prefix='robot4wd-tests-') as d:
 for name in names:
  binary=str(Path(d)/name)
  build=subprocess.run([compiler,'-std=c++17','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I'+str(root/'tests'),str(root/'tests'/f'{name}.cpp'),'-o',binary],capture_output=True,text=True)
  run=subprocess.run([binary],capture_output=True,text=True) if build.returncode==0 else build
  results.append({'test':name,'exit':run.returncode,'output':run.stdout+run.stderr})
  print(name, 'PASS' if run.returncode==0 else 'FAIL', run.stdout+run.stderr)
(root/'data/submission-host-tests.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
raise SystemExit(0 if all(r['exit']==0 for r in results) else 1)
