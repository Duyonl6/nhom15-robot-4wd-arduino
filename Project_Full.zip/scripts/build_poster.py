from pathlib import Path
from math import atan2,sin,cos,pi
import json
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor,Color
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle
from reportlab.graphics.barcode import qr
from reportlab.graphics.shapes import Drawing
from reportlab.graphics import renderPDF
import fitz
ROOT=Path(__file__).resolve().parents[1]
R=ROOT if (ROOT/'team.json').exists() else ROOT/'outputs/nhom15-robot-4wd-arduino'
for n,f in [('Regular','WorkSans-Regular.ttf'),('Bold','WorkSans-Bold.ttf'),('Display','BricolageGrotesque-Bold.ttf')]:
 pdfmetrics.registerFont(TTFont(n,str(R/'assets/fonts'/f)))
pdfmetrics.registerFontFamily('Regular',normal='Regular',bold='Bold',italic='Regular',boldItalic='Bold')
team=json.loads((R/'team.json').read_text())
W,H=595.2756,841.8898
navy='#102F42';teal='#007F79';mint='#E7F4EF';ink='#19394A';muted='#546976';orange='#B96B21';light='#F0F4F5';line='#D9E2E6'
C=None
boxes=[]
def rect(x,y,w,h,fill,stroke=None,r=0):
 C.setFillColor(HexColor(fill));C.setStrokeColor(HexColor(stroke or fill));C.setLineWidth(.6)
 if r:C.roundRect(x,H-y-h,w,h,r,fill=1,stroke=bool(stroke))
 else:C.rect(x,H-y-h,w,h,fill=1,stroke=bool(stroke))
def txt(x,y,s,size=9,font='Regular',color=ink):
 C.setFont(font,size);C.setFillColor(HexColor(color));C.drawString(x,H-y-size,s)
 boxes.append((x,y,x+pdfmetrics.stringWidth(s,font,size),y+size,s))
def para(x,y,w,s,size=8.7,color=ink,leading=None,font='Regular'):
 st=ParagraphStyle('p',fontName=font,fontSize=size,leading=leading or size*1.4,textColor=HexColor(color))
 p=Paragraph(s,st);_,h=p.wrap(w,500);p.drawOn(C,x,H-y-h)
 boxes.append((x,y,x+w,y+h,s));return h

def seg(x1,y1,x2,y2,color=line,width=.8,arrow=False):
 C.setStrokeColor(HexColor(color));C.setFillColor(HexColor(color));C.setLineWidth(width);C.line(x1,H-y1,x2,H-y2)
 if arrow:
  a=atan2(y2-y1,x2-x1);p=C.beginPath();p.moveTo(x2,H-y2)
  for d in [-.42,.42]:p.lineTo(x2-4*cos(a+d),H-(y2-4*sin(a+d)))
  p.close();C.drawPath(p,fill=1,stroke=0)

def section(n,label,y,x=24):
 txt(x,y,n,8.1,'Bold',teal);txt(x+20,y-1,label,10,'Bold',navy)

def wheel(x,y,w=20,h=35):
 rect(x,y,w,h,navy,r=3)
 for yy in range(int(y+5),int(y+h-2),5):seg(x+3,yy,x+w-3,yy,'#315365',.7)

def robot(x,y):
 # Stylised structural drawing, explicitly labelled as such.
 rect(x+30,y+10,108,98,'#D9E9E6',teal,r=12)
 for xx in [x+17,x+132]:
  wheel(xx,y+15);wheel(xx,y+70)
 rect(x+59,y+37,44,48,navy,r=3)
 for i in range(6):
  rect(x+54,y+41+i*7,5,2,'#7D9A9E');rect(x+103,y+41+i*7,5,2,'#7D9A9E')
 txt(x+65,y+48,'NANO',7,'Bold','#FFFFFF');txt(x+68,y+61,'328P',6,'Regular','#B4D5D9')
 rect(x+55,y+1,52,22,'#FFFFFF',teal,r=3)
 for xx in [x+67,x+94]:
  C.setFillColor(HexColor(navy));C.circle(xx,H-(y+12),7,fill=1,stroke=0)
  C.setStrokeColor(HexColor('#7898A2'));C.circle(xx,H-(y+12),4.8,fill=0,stroke=1)
 rect(x+57,y+100,49,10,teal,r=2)
 for i in range(5):
  C.setFillColor(HexColor('#FFFFFF'));C.circle(x+64+i*9,H-(y+105),1.8,fill=1,stroke=0)
 seg(x+82,y-7,x+82,y-17,teal,1.1,True)
 txt(x+10,y+119,'Minh họa cấu trúc 4WD',7,'Regular',muted)

def diagram(y, standalone=False):
 # Complete functional data paths; power shown as annotation.
 x=24; bw=125
 def node(xx,yy,w,h,title,sub='',primary=False):
  rect(xx,yy,w,h,navy if primary else light,None if primary else line,r=5)
  txt(xx+9,yy+6,title,9,'Bold','#FFFFFF' if primary else ink)
  if sub:txt(xx+9,yy+20,sub,7,'Regular','#C5E3E4' if primary else muted)
 node(24,y,125,34,'Điện thoại Dabble','GamePad Digital')
 node(24,y+48,125,34,'BT05','Bluetooth BLE · UART')
 node(209,y+24,174,49,'ARDUINO NANO','ATmega328P · máy trạng thái',True)
 node(24,y+96,125,34,'Cảm biến đầu vào','5 mắt IR · HC-SR04 · encoder')
 node(443,y+3,128,34,'L298N → 4 motor','PWM + tín hiệu chiều')
 node(443,y+82,128,34,'Servo đầu quét','Quét trái / phải')
 seg(86,y+34,86,y+48,teal,1,True)
 seg(149,y+65,183,y+65,teal,1);seg(183,y+65,183,y+40,teal,1);seg(183,y+40,209,y+40,teal,1,True)
 seg(149,y+112,191,y+112,teal,1);seg(191,y+112,191,y+60,teal,1);seg(191,y+60,209,y+60,teal,1,True)
 seg(383,y+39,414,y+39,teal,1);seg(414,y+39,414,y+20,teal,1);seg(414,y+20,443,y+20,teal,1,True)
 seg(383,y+59,414,y+59,teal,1);seg(414,y+59,414,y+99,teal,1);seg(414,y+99,443,y+99,teal,1,True)
 txt(211,y+91,'Nguồn pin → khối công suất',7.4,'Regular',muted)
 txt(211,y+103,'Nguồn logic / cảm biến · GND chung',7.0,'Regular',muted)

def make():
 global C,boxes
 C=canvas.Canvas(str(R/'Poster_A4.pdf'),pagesize=(W,H),pageCompression=1)
 C.setTitle('Nhóm 15 - Robot 4 bánh Arduino');C.setAuthor('Nguyễn Đức Minh; Nguyễn Minh Quân')
 rect(0,0,W,110,navy)
 txt(24,18,'BÀI TẬP LỚN  /  HỆ THỐNG NHÚNG',8.6,'Bold','#B4D5D9')
 rect(493,18,78,20,teal,r=4);txt(507,22,'NHÓM 15',9,'Bold','#FFFFFF')
 txt(24,39,'ROBOT 4 BÁNH',34,'Display','#FFFFFF')
 txt(25,85,'Điều khiển Bluetooth  /  Dò line  /  Tránh vật cản',10.3,'Regular','#FFFFFF')
 rect(24,122,547,33,light,r=5)
 txt(36,130,'THÀNH VIÊN',7.6,'Bold',muted)
 txt(143,129,'Nguyễn Đức Minh',10.4,'Bold',navy)
 txt(349,129,'Nguyễn Minh Quân',10.4,'Bold',navy)
 section('01','GIỚI THIỆU',170)
 para(24,190,325,'Mô hình xe tự hành 4 bánh dùng Arduino Nano, kết hợp điều khiển từ điện thoại và cảm biến môi trường. Hệ thống phục vụ học tập, thử nghiệm thuật toán dò vạch và tránh vật cản.',9,leading=13)
 rect(24,254,90,23,mint,r=4);txt(36,260,'Arduino Nano',8,'Bold',teal)
 rect(120,254,92,23,mint,r=4);txt(132,260,'Bluetooth BLE',8,'Bold',teal)
 rect(218,254,104,23,mint,r=4);txt(230,260,'03 chế độ',8,'Bold',teal)
 robot(393,169)
 section('02','SƠ ĐỒ HỆ THỐNG',304)
 diagram(326)
 section('03','PHƯƠNG PHÁP ĐỀ XUẤT',474)
 def method(x,y,n,title,s):
  txt(x,y,n,8,'Bold',teal);txt(x+17,y-1,title,9,'Bold',navy)
  return para(x+17,y+14,238,s,8.1,leading=11.1)
 method(24,497,'A','Điều khiển theo trạng thái','Chọn 1 trong 3 chế độ trên Dabble; START chạy/tạm dừng; × hoặc SELECT dừng xe.')
 method(310,497,'B','Dò line có phản hồi','5 mắt IR tính sai lệch vạch; PD lái kết hợp PI bù tốc độ theo encoder, chu kỳ 200 ms.')
 method(24,553,'C','Quét và tránh vật cản','HC-SR04 đo không chặn; vật gần dưới 20 cm → dừng, quét trái/phải, chọn hướng thoáng.')
 method(310,553,'D','Giám sát vận hành','Lọc khung Bluetooth; giám sát liên kết BT05, mất vạch và encoder không tiến triển.')
 section('04','KẾT QUẢ',614)
 rect(24,636,113,87,mint,r=6)
 txt(36,642,'6/6',28,'Display',teal)
 txt(36,677,'bộ kiểm thử phần mềm',7.1,'Bold',teal)
 txt(36,692,'v2.4 · 16.422 B flash',7.1,'Regular',muted)
 txt(36,703,'SRAM tĩnh: 667 B',7.1,'Regular',muted)
 para(153,637,405,'<b>Thử bằng pin:</b> ghi nhận lái tay và tránh vật cản hoạt động ổn.',8.5,leading=12.3)
 para(153,667,405,'<b>Dò line:</b> đã nhận vật đen mờ; cần hạ cụm HW-871. Chưa xác minh bám vạch hoàn chỉnh trên sàn sau điều chỉnh.',8.5,leading=12.3)
 txt(153,708,'Minh chứng: log biên dịch / verify và dữ liệu kiểm tra ngày 22/11/2026.',7.1,'Regular',muted)
 section('05','KẾT LUẬN',740)
 section('06','HƯỚNG PHÁT TRIỂN',740,x=310)
 para(24,759,258,'Đã tích hợp 3 chế độ trong cùng firmware; lái tay và tránh vật đã thử bằng pin. Cần hoàn thiện cơ khí cụm dò line.',8.0,leading=11)
 para(310,759,261,'Hạ cảm biến, hiệu chuẩn encoder và góc quay; thử bám vạch nhiều lượt; tối ưu điều khiển, bổ sung giám sát pin.',8.0,leading=11)
 seg(24,805,571,805,line,.8)
 txt(24,815,'github.com/Duyonl6/nhom15-robot-4wd-arduino',7.5,'Bold',teal)
 C.linkURL(team['repository'],(24,H-826,400,H-811),relative=0)
 txt(466,815,'23 / 11 / 2026',7.7,'Regular',muted)
 C.save()
 d=fitz.open(R/'Poster_A4.pdf');p=d[0];pix=p.get_pixmap(matrix=fitz.Matrix(300/72,300/72));pix.set_dpi(300,300);pix.save(R/'Poster_A4.png')
 p.get_pixmap(matrix=fitz.Matrix(1.6,1.6)).save(R/'Poster_preview.png')
 # Standalone system diagram, same vector as the poster, with enough top/bottom space.
 C=canvas.Canvas(str(R/'docs/system-diagram.pdf'),pagesize=(W,190))
 C.translate(0,190-H)
 txt(24,14,'SƠ ĐỒ HỆ THỐNG ROBOT 4 BÁNH',13,'Bold',navy)
 diagram(42);C.save()
 d2=fitz.open(R/'docs/system-diagram.pdf');d2[0].get_pixmap(matrix=fitz.Matrix(2,2)).save(R/'docs/system-diagram.png')
 print('poster generated',W,H)
 print('out-of-bounds',[(b[0:4],b[4][:30]) for b in boxes if b[0]<0 or b[1]<0 or b[2]>W or b[3]>H])
if __name__=='__main__':make()
